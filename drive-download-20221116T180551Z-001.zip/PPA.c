#include<stdio.h>

int main()
{
    printf("Revision session 18th August.\n");

    return 0;
}