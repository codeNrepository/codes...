
import java.lang.*;

class Demo
{
    // Code
}

// After compilation the above class becomes

class Demo extends Object
{
    // Code
}

// This class is stored in java.lang package
public class Object
{
    public boolean equals()
    {}

    public String toString()
    {}

    public clone()
    {}

    protected finalise()
    {}

    public int hashcode()
    {}

    public Class getClass()
    {}
}