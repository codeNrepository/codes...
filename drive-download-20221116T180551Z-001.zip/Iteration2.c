#include<stdio.h>

int main()
{
    int iCnt = 0;

    //      1          2        3
    for(iCnt = 1; iCnt < 6; iCnt++)
    {
        printf("Jay Ganesh..\n");   // 4
    }
    
    return 0;
}