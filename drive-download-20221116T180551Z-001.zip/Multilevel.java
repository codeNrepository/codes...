class A
{
     
}

class B extends A
{

}

class C extends B
{

}

class Multilevel
{
     public static void main(String p[])
     {

     }
}