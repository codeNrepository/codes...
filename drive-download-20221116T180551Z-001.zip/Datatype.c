#include<stdio.h>

int main()
{
    int iNo1 = 10;
    float fValue = 3.14;
    double dData = 6.10;
    char cValue = 'M';

   printf("Integer is %d\n",iNo1);
   printf("Float is %f\n",fValue);
   printf("Double is %lf\n",dData);
   printf("Character is %c\n",cValue);

    return 0;
}

/*
    %d      Decimal             int
    %f      Float                  float
    %lf     Long float          double
    %c      Chracter            char
    %s      String                string
*/



