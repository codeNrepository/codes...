#include<stdio.h>








int main()
{
    int No1 = 10;

    int No2 = 11;

    int Ans = 0;

    Ans = No1 + No2;

    printf("%d\n",Ans);

    return 0;
}
