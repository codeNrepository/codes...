#include<stdio.h>

// Definations of global variables
// Scope : Throughout the program
int No1 = 11;                   // Global variable

// Scope : Throughout the file
static int No2 = 21;            // Global static variable