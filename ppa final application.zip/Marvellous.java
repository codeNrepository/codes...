
class Marvellous
{
     public static void main(String arr[])
     {
          System.out.println("Inside main function");
     }
}

// mobj.main()
// Marvellous.main()