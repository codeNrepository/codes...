// Case 6
interface Demo 
{
}
interface Hello 
{
}
class Marvellous implements Demo, Hello
{
}