#include<stdio.h>

int main()
{
    int A;
    int B = 0;
    int C = 10;
    auto int D;
    auto int E = 0;

    register int No = 11;

    return 0;
}