import java.awt.*;

class GUI1
{
    public static void main(String arg[])
    {
        Frame fobj = new Frame("Marvellous");

        fobj.setSize(500,500);

        fobj.setVisible(true);
    }
}